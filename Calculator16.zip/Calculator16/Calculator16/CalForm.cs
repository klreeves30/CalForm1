﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator16
{
    public partial class CalForm : Form
    {
        public CalForm()
        {
            InitializeComponent();
        }

        private decimal firstNum = 0.0m;
        private decimal secondNum = 0.0m;
        private decimal result = 0.0m;
        private int operatorType = (int)MathOperations.NoOperator;

        public enum MathOperations
        {
            NoOperator = 0,
            Add = 1,
            Minus = 2,
            Divide = 3,
            Multiply = 4,
            Percentage = 5,
        }

        private void DigitBtn_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;

            if (DisplayTextBox1.Text == "0")
            {
                DisplayTextBox1.Clear();
            }

            DisplayTextBox1.Text += btn.Text;
        }

        private void CalForm_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (!DisplayTextBox1.Text.Contains("."))
            {
                DisplayTextBox1.Text += ".";
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!DisplayTextBox1.Text.Contains("-"))
            {
                DisplayTextBox1.Text = "-" + DisplayTextBox1.Text;
            }
            else
            {
                DisplayTextBox1.Text = DisplayTextBox1.Text.Trim('-');
            }
        }

        private void DivideButton_Click(object sender, EventArgs e)
        {
            SaveValueOperatorType((int)MathOperations.Divide);
        }

        private void AdditionButton_Click(object sender, EventArgs e)
        {
            SaveValueOperatorType((int)MathOperations.Add);
        }

        private void SubtractButtton_Click(object sender, EventArgs e)
        {
            SaveValueOperatorType((int)MathOperations.Minus);
        }

        private void SaveValueOperatorType(int operation)
        {
            operatorType = operation;
            firstNum = Convert.ToDecimal(DisplayTextBox1.Text);
            DisplayTextBox1.Text = "0";
        }

        private void MultiplyButton_Click(object sender, EventArgs e)
        {
            SaveValueOperatorType((int)MathOperations.Multiply);
        }

        private void PercentageButton_Click(object sender, EventArgs e)
        {
            SaveValueOperatorType((int)MathOperations.Percentage);
        }

        private void EqualButton_Click(object sender, EventArgs e)
        {
            secondNum = Convert.ToDecimal(DisplayTextBox1.Text);

            switch (operatorType)
            {
                case (int)MathOperations.Add:
                    result = firstNum + secondNum;
                    break;
                case (int)MathOperations.Minus:
                    result = firstNum - secondNum;
                    break;
                case (int)MathOperations.Divide:
                    result = firstNum / secondNum;
                    break;
                case (int)MathOperations.Multiply:
                    result = firstNum * secondNum;
                    break;
                case (int)MathOperations.Percentage:
                    result = (firstNum / secondNum) * 100;
                    break;         
          }

            DisplayTextBox1.Text = result.ToString();
        }

        private void ClearEntryButton_Click(object sender, EventArgs e)
        {
            DisplayTextBox1.Text = "0";
        }

        private void ClearButton_Click(object sender, EventArgs e)
        {
            DisplayTextBox1.Text = "0";
            firstNum = 0.0m;
            secondNum = 0.0m;
            result = 0;
            operatorType = (int)MathOperations.NoOperator;
        }
    }
}  




